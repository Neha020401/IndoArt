import './App.css';
import { Routes,Route } from 'react-router-dom';
import Navbar from './Components/Navbar/Navbar';
import Home from './Components/Home/Home'
import Auth from './Components/Auth/Auth';
import Footer from './Footer/Footer';
import ChatRoom from './Components/Chat/ChatRoom';

function App() {
  return (
 <div>
<Navbar/>
<Routes>
<Route  excat path='/' element={<Home/>}/>
<Route path='/auth' element={<Auth/>}/>
<Route path='/chatRoom' element={<ChatRoom/>}/>
</Routes>
<Footer />
 </div>
  );
}

export default App;
