import React from 'react'

const Footer = () => {
  return (
    <div className='Footer' style={{height:'200px',background:'black',color:'white'}}>
      <p>
        Social  Media Logos
      </p>
      <p>
        Contacts
      </p>
    </div>
  )
}

export default Footer
